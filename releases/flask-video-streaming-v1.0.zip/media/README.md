This is where captured photos are saved
