drop table if exists media;
create table media (
       id INTEGER primary key autoincrement,
       date timestamp,
       fileName TEXT
);
